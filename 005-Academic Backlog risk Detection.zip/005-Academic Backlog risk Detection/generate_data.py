import sqlite3
import random

conn = sqlite3.connect("database/students.db")
cursor = conn.cursor()

for i in range(500):

    attendance = random.randint(40,100)
    internal = random.randint(30,100)
    assignment = random.randint(30,100)
    study_hours = random.randint(1,8)

    risk_score = attendance + internal + assignment + (study_hours*10)

    if risk_score < 180:
        backlog = 1
    else:
        backlog = 0

    cursor.execute(
        "INSERT INTO students(attendance,internal_marks,assignment_score,study_hours,backlog) VALUES (?,?,?,?,?)",
        (attendance,internal,assignment,study_hours,backlog)
    )

conn.commit()
conn.close()

print("Sample data generated successfully")
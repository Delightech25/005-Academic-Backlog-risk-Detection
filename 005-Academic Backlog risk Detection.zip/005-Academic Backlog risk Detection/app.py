from flask import Flask,render_template,request,redirect,session
import sqlite3
import pickle

app = Flask(__name__)
app.secret_key = "secret123"

model = pickle.load(open("model/backlog_model.pkl","rb"))

# ---------------- LOGIN ----------------

@app.route('/')
def login():
    return render_template("login.html")

@app.route('/login',methods=['POST'])
def login_user():

    username = request.form['username']
    password = request.form['password']

    conn = sqlite3.connect("database/students.db")
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM users WHERE username=? AND password=?",(username,password))
    user = cursor.fetchone()

    conn.close()

    if user:
        session['user'] = username
        return redirect("/dashboard")
    else:
        return "Invalid login"


# ---------------- REGISTER ----------------

@app.route('/register')
def register():
    return render_template("register.html")

@app.route('/register_user',methods=['POST'])
def register_user():

    username = request.form['username']
    password = request.form['password']

    conn = sqlite3.connect("database/students.db")
    cursor = conn.cursor()

    cursor.execute("INSERT INTO users(username,password) VALUES (?,?)",(username,password))

    conn.commit()
    conn.close()

    return redirect("/")

# ---------------- DASHBOARD ----------------

@app.route('/dashboard')
def dashboard():

    if 'user' not in session:
        return redirect("/")

    conn = sqlite3.connect("database/students.db")
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM students")
    students = cursor.fetchall()

    conn.close()

    return render_template("dashboard.html",students=students,user=session['user'])


# ---------------- PREDICTION ----------------

@app.route('/predict',methods=['POST'])
def predict():

    attendance = int(request.form['attendance'])
    internal = int(request.form['internal'])
    assignment = int(request.form['assignment'])
    study = int(request.form['study'])

    prediction = model.predict([[attendance,internal,assignment,study]])

    if prediction[0] == 1:
        result = "High Backlog Risk"
        plan_type = "high"
    else:
        result = "Low Backlog Risk"
        plan_type = "low"

    conn = sqlite3.connect("database/students.db")
    cursor = conn.cursor()

    cursor.execute(
        "INSERT INTO students(attendance,internal_marks,assignment_score,study_hours,backlog) VALUES (?,?,?,?,?)",
        (attendance,internal,assignment,study,prediction[0])
    )

    conn.commit()
    conn.close()

    return render_template("result.html",result=result,plan_type=plan_type)


# ---------------- LOGOUT ----------------

@app.route('/logout')
def logout():
    session.pop('user',None)
    return redirect("/")


if __name__ == "__main__":
    app.run(debug=True)
import sqlite3
import os

os.makedirs("database", exist_ok=True)

conn = sqlite3.connect("database/students.db")
cursor = conn.cursor()

# students table
cursor.execute("""
CREATE TABLE IF NOT EXISTS students(
id INTEGER PRIMARY KEY AUTOINCREMENT,
attendance INTEGER,
internal_marks INTEGER,
assignment_score INTEGER,
study_hours INTEGER,
backlog INTEGER
)
""")

# users table
cursor.execute("""
CREATE TABLE IF NOT EXISTS users(
id INTEGER PRIMARY KEY AUTOINCREMENT,
username TEXT UNIQUE,
password TEXT
)
""")

conn.commit()
conn.close()

print("Database ready")
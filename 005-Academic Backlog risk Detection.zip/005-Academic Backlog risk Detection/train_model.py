import sqlite3
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
import pickle
import os

os.makedirs("model", exist_ok=True)

conn = sqlite3.connect("database/students.db")

data = pd.read_sql_query("SELECT * FROM students", conn)

X = data[['attendance','internal_marks','assignment_score','study_hours']]
y = data['backlog']

X_train,X_test,y_train,y_test = train_test_split(X,y,test_size=0.2)

model = RandomForestClassifier()
model.fit(X_train,y_train)

pickle.dump(model,open("model/backlog_model.pkl","wb"))

print("Model trained successfully")